import hashlib
from fileManager import user_manager


admin_name = '00'
admin_password = '00'


class User:
    def __init__(self, name, password, phone):
        self.name = name
        self.password = password
        self.phone = phone
        self.active = False

    @staticmethod
    def hash_password(password):
        return hashlib.sha256(password.encode()).hexdigest()

    @staticmethod
    def active_user():
        all_users = user_manager.read()
        idx = 0
        while idx < len(all_users):
            if all_users[idx]['active'] is True:
                return all_users[idx]
            idx += 1


class Teacher(User):
    def __init__(self, name, password, phone, subject, experience):
        super().__init__(name, password, phone)
        self.subject = subject
        self.experience = experience
        self.kind = 'teacher'


class Student(User):
    def __init__(self, name, password, phone, specialty, stage):
        super().__init__(name, password, phone)
        self.specialty = specialty
        self.stage = stage
        self.kind = 'student'


def login() -> int:
    # This function belongs to auth_menu()
    name = input('Enter your name: ')
    password = input('Enter your password: ')
    if name == admin_name and password == admin_password:
        return 1
    password = User.hash_password(password)
    all_users = user_manager.read()
    idx = 0
    while idx < len(all_users):
        if all_users[idx]['name'] == name and all_users[idx]['password'] == password:
            all_users[idx]['active'] = True
            user_manager.write(all_users)
            if all_users[idx]['kind'] == 'teacher':
                return 2
            else:
                return 3
        idx += 1
    else:
        return 4


def logout():
    all_users = user_manager.read()
    idx = 0
    while idx < len(all_users):
        if all_users[idx]['active'] is True:
            all_users[idx]['active'] = False
            user_manager.write(all_users)
        idx += 1


def add_teacher():
    name = input('Teacher name: ')
    password = User.hash_password(input('Password: '))
    subject = input('Subject: ')
    try:
        phone = int(input("Phone: "))
        experience = int(input('Experience: '))
    except ValueError:
        print('Phone and experience must be a whole number!')
        return add_teacher()
    teacher = Teacher(name, password, phone, subject, experience)
    user_manager.add(teacher.__dict__)
    print('Successfully added!')


def del_teacher():
    name = input('Teacher name: ')
    try:
        phone = int(input("Phone: "))
    except ValueError:
        print('Phone number must be a whole number!')
        return del_teacher()
    all_users = user_manager.read()
    idx = 0
    while idx < len(all_users):
        if all_users[idx]['name'] == name and all_users[idx]['phone'] == phone:
            del all_users[idx]
            user_manager.write(all_users)
            print('Deleted')
            return
        idx += 1
    else:
        print('No such a teacher')
        return


def show_teachers():
    all_users = user_manager.read()
    print('Name - Phone - Subject')
    for user in all_users:
        if user['kind'] == 'teacher':
            print(f'{user["name"]} - {user["phone"]} - {user["subject"]}')


def find_teacher(name):
    all_users = user_manager.read()
    for user in all_users:
        if user['name'] == name and user['kind'] == 'teacher':
            return True
    else:
        return False


def add_student():
    name = input('Student name: ')
    password = User.hash_password(input('Password: '))
    specialty = input('Specialty: ')
    try:
        phone = int(input("Phone: "))
        stage = int(input('Stage: '))
    except ValueError:
        print('Phone and stage must be a whole number!')
        return add_student()
    student = Student(name, password, phone, specialty, stage)
    user_manager.add(student.__dict__)
    print('Successfully added!')


def del_student():
    name = input('Student name: ')
    try:
        phone = int(input("Phone: "))
    except ValueError:
        print('Phone number must be a whole number!')
        return del_student()
    all_users = user_manager.read()
    idx = 0
    while idx < len(all_users):
        if all_users[idx]['name'] == name and all_users[idx]['phone'] == phone:
            del all_users[idx]
            user_manager.write(all_users)
            print('Deleted')
            return
        idx += 1
    else:
        print('No such a student')
        return


def show_students():
    all_users = user_manager.read()
    print('Name - Phone - Specialty')
    for user in all_users:
        if user['kind'] == 'student':
            print(f'{user["name"]} - {user["phone"]} - {user["specialty"]}')
